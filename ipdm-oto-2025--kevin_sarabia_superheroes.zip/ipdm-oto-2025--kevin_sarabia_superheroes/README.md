# App Superheroes

Esta aplicación muestra una lista de superhéroes ficticios, utilizando Jetpack Compose y diseño en tarjetas.

## Características

- Jetpack Compose
- Lista desplazable
- Temas personalizados
- Código 100% original

## Captura

![Captura](captura_superheroes.png)